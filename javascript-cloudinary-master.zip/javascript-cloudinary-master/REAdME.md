# Javascript & Cloudinary Upload Example
![](screenshot.gif)